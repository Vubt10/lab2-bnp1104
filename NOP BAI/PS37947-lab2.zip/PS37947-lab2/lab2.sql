﻿
USE master;
GO


IF EXISTS (SELECT name FROM sys.databases WHERE name = 'QLDA')
BEGIN
  
    ALTER DATABASE QLDA SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE QLDA;
    PRINT N'Đã xóa database QLDA cũ';
END
GO


CREATE DATABASE QLDA;
GO


USE QLDA;
GO

CREATE TABLE PHONGBAN (
    MAPHG int PRIMARY KEY,
    TENPHG nvarchar(15) NOT NULL,
    TRPHG nvarchar(9) NOT NULL,
    NG_NHANCHUC date
);

CREATE TABLE DIADIEM_PHG (
    MAPHG int,
    DIADIEM nvarchar(15),
    PRIMARY KEY (MAPHG, DIADIEM),
    FOREIGN KEY (MAPHG) REFERENCES PHONGBAN(MAPHG)
);

CREATE TABLE NHANVIEN (
    MANV nvarchar(9) PRIMARY KEY,
    HONV nvarchar(15) NOT NULL,
    TENLOT nvarchar(15),
    TENNV nvarchar(15) NOT NULL,
    NGSINH date,
    DCHI nvarchar(30),
    PHAI nvarchar(3),
    LUONG float,
    MA_NQL nvarchar(9),
    PHG int,
    FOREIGN KEY (MA_NQL) REFERENCES NHANVIEN(MANV),
    FOREIGN KEY (PHG) REFERENCES PHONGBAN(MAPHG)
);

ALTER TABLE PHONGBAN
ADD FOREIGN KEY (TRPHG) REFERENCES NHANVIEN(MANV);

CREATE TABLE DEAN (
    MADA int PRIMARY KEY,
    TENDA nvarchar(15) NOT NULL,
    DDIEM_DA nvarchar(15),
    PHONG int,
    FOREIGN KEY (PHONG) REFERENCES PHONGBAN(MAPHG)
);

CREATE TABLE CONGVIEC (
    MADA int,
    STT int,
    TEN_CONG_VIEC nvarchar(50),
    PRIMARY KEY (MADA, STT),
    FOREIGN KEY (MADA) REFERENCES DEAN(MADA)
);

CREATE TABLE PHANCONG (
    MANV nvarchar(9),
    MADA int,
    STT int,
    THOIGIAN float,
    PRIMARY KEY (MANV, MADA, STT),
    FOREIGN KEY (MANV) REFERENCES NHANVIEN(MANV),
    FOREIGN KEY (MADA, STT) REFERENCES CONGVIEC(MADA, STT)
);

CREATE TABLE THANNHAN (
    MANV nvarchar(9),
    TENTN nvarchar(15),
    PHAI nvarchar(3),
    NGSINH date,
    QUANHE nvarchar(15),
    PRIMARY KEY (MANV, TENTN),
    FOREIGN KEY (MANV) REFERENCES NHANVIEN(MANV)
);


ALTER TABLE PHONGBAN NOCHECK CONSTRAINT ALL;
ALTER TABLE NHANVIEN NOCHECK CONSTRAINT ALL;

IF NOT EXISTS (SELECT 1 FROM PHONGBAN WHERE MAPHG = 1)
BEGIN
    INSERT INTO PHONGBAN VALUES 
    (1, N'Nghiên cứu', '333445555', '1988-05-22'),
    (4, N'Điều hành', '987654321', '1995-01-01'),
    (5, N'IT', '123456789', '1999-05-15');
    PRINT N'Đã chèn dữ liệu vào bảng PHONGBAN';
END

IF NOT EXISTS (SELECT 1 FROM NHANVIEN WHERE MANV = '123456789')
BEGIN
    INSERT INTO NHANVIEN VALUES
    ('123456789', N'Trần', N'Thanh', N'Thanh', '1965-01-09', N'731 Trần Hưng Đạo, TP HCM', N'Nam', 30000, '333445555', 5),
    ('333445555', N'Nguyễn', N'Thanh', N'Tùng', '1955-12-08', N'638 Võ Văn Kiệt, TP HCM', N'Nam', 40000, '888665555', 1),
    ('999887777', N'Nguyễn', N'Thanh', N'Tâm', '1968-09-19', N'975 Lê Lai, Vũng Tàu', N'Nam', 25000, '987654321', 4),
    ('987654321', N'Phạm', N'Văn', N'Vinh', '1941-06-20', N'291 Hồ Văn Huê, TP HCM', N'Nam', 43000, '888665555', 4),
    ('666884444', N'Trịnh', N'Thanh', N'Ngọc', '1962-09-15', N'168 Nguyễn Văn B, TP HCM', N'Nữ', 38000, '333445555', 1),
    ('453453453', N'Trịnh', N'Thanh', N'Ngọc', '1972-07-31', N'445 Nguyễn Xiển, Long Thành', N'Nữ', 25000, '333445555', 1),
    ('987987987', N'Lê', N'Thị Hồng', N'Vân', '1979-05-29', N'101 Lý Thường Kiệt, TP HCM', N'Nữ', 43000, '987654321', 4),
    ('888665555', N'Vương', N'Ngọc', N'Quyền', '1937-11-10', N'450 Trần Hưng Đạo, TP HCM', N'Nam', 55000, NULL, 1);
    PRINT N'Đã chèn dữ liệu vào bảng NHANVIEN';
END

IF NOT EXISTS (SELECT 1 FROM DIADIEM_PHG WHERE MAPHG = 1 AND DIADIEM = N'TP HCM')
BEGIN
    INSERT INTO DIADIEM_PHG VALUES
    (1, N'TP HCM'),
    (4, N'Hà Nội'),
    (5, N'Nha Trang'),
    (5, N'TP HCM'),
    (5, N'Vũng Tàu');
    PRINT N'Đã chèn dữ liệu vào bảng DIADIEM_PHG';
END

IF NOT EXISTS (SELECT 1 FROM DEAN WHERE MADA = 1)
BEGIN
    INSERT INTO DEAN VALUES
    (1, N'Sản phẩm X', N'Vũng Tàu', 1),
    (2, N'Sản phẩm Y', N'Nha Trang', 1),
    (3, N'Sản phẩm Z', N'TP HCM', 1),
    (10, N'Tin học hóa', N'Hà Nội', 4),
    (20, N'Tái tổ chức', N'TP HCM', 1),
    (30, N'Đ.án mới', N'Vũng Tàu', 4);
    PRINT N'Đã chèn dữ liệu vào bảng DEAN';
END

IF NOT EXISTS (SELECT 1 FROM CONGVIEC WHERE MADA = 1 AND STT = 1)
BEGIN
    INSERT INTO CONGVIEC VALUES
    (1, 1, N'Thiết kế sản phẩm'),
    (1, 2, N'Xây dựng nhà xưởng'),
    (2, 1, N'Công nghệ chế tạo'),
    (2, 2, N'Thử nghiệm sản phẩm'),
    (3, 1, N'Thiết kế quảng cáo'),
    (10, 1, N'Phân tích hệ thống'),
    (10, 2, N'Thiết kế hệ thống'),
    (20, 1, N'Đánh giá nhân sự'),
    (30, 1, N'Khảo sát địa điểm');
    PRINT N'Đã chèn dữ liệu vào bảng CONGVIEC';
END

IF NOT EXISTS (SELECT 1 FROM PHANCONG WHERE MANV = '123456789' AND MADA = 1 AND STT = 1)
BEGIN
    INSERT INTO PHANCONG VALUES
    ('123456789', 1, 1, 32.5),  -- Dự án 1, công việc 1
    ('123456789', 2, 1, 7.5),   -- Dự án 2, công việc 1
    ('666884444', 3, 1, 40.0),  -- Dự án 3, công việc 1
    ('453453453', 1, 2, 20.0),  -- Dự án 1, công việc 2
    ('453453453', 2, 1, 20.0),  -- Dự án 2, công việc 1
    ('333445555', 2, 2, 10.0),  -- Dự án 2, công việc 2
    ('333445555', 3, 1, 10.0),  -- Dự án 3, công việc 1
    ('333445555', 10, 1, 10.0), -- Dự án 10, công việc 1
    ('333445555', 20, 1, 15.0), -- Dự án 20, công việc 1
    ('999887777', 30, 1, 30.0), -- Dự án 30, công việc 1
    ('999887777', 10, 2, 10.0), -- Dự án 10, công việc 2
    ('987987987', 10, 1, 35.0), -- Dự án 10, công việc 1
    ('987654321', 30, 1, 20.0), -- Dự án 30, công việc 1
    ('987654321', 20, 1, 15.0), -- Dự án 20, công việc 1
    ('888665555', 20, 1, 0);    -- Dự án 20, công việc 1
    PRINT N'Đã chèn dữ liệu vào bảng PHANCONG';
END

IF NOT EXISTS (SELECT 1 FROM THANNHAN WHERE MANV = '333445555' AND TENTN = N'Joyce')
BEGIN
    INSERT INTO THANNHAN VALUES
    ('333445555', N'Joyce', N'Nữ', '1986-04-05', N'Con gái'),
    ('333445555', N'Minh', N'Nam', '1983-01-01', N'Con trai'),
    ('333445555', N'Hằng', N'Nữ', '1958-05-03', N'Vợ chồng'),
    ('987654321', N'Abner', N'Nam', '1942-02-28', N'Vợ chồng'),
    ('123456789', N'Minh', N'Nam', '1988-01-04', N'Con trai'),
    ('123456789', N'Alice', N'Nữ', '1986-12-30', N'Con gái'),
    ('123456789', N'Elizabeth', N'Nữ', '1967-05-05', N'Vợ chồng');
    PRINT N'Đã chèn dữ liệu vào bảng THANNHAN';
END

ALTER TABLE PHONGBAN CHECK CONSTRAINT ALL;
ALTER TABLE NHANVIEN CHECK CONSTRAINT ALL;

PRINT N'=== HOÀN THÀNH CHÈN DỮ LIỆU ===';

DECLARE @ChieuDai float = 10.5;
DECLARE @ChieuRong float = 7.2;
DECLARE @DienTich float;
DECLARE @ChuVi float;

SET @DienTich = @ChieuDai * @ChieuRong;
SET @ChuVi = 2 * (@ChieuDai + @ChieuRong);

PRINT N'Chiều dài: ' + CAST(@ChieuDai AS varchar(10));
PRINT N'Chiều rộng: ' + CAST(@ChieuRong AS varchar(10));
PRINT N'Diện tích: ' + CAST(@DienTich AS varchar(10));
PRINT N'Chu vi: ' + CAST(@ChuVi AS varchar(10));

DECLARE @LuongCaoNhat float;
DECLARE @TenNVLuongCaoNhat nvarchar(50);

SELECT @LuongCaoNhat = MAX(LUONG) FROM NHANVIEN;

SELECT @TenNVLuongCaoNhat = HONV + ' ' + ISNULL(TENLOT + ' ', '') + TENNV 
FROM NHANVIEN 
WHERE LUONG = @LuongCaoNhat;

PRINT N'Nhân viên có lương cao nhất: ' + @TenNVLuongCaoNhat + 
      N' - Lương: ' + CAST(@LuongCaoNhat AS varchar(20));

DECLARE @LuongTBNghienCuu float;
DECLARE @MaPhongNghienCuu int;

SELECT @MaPhongNghienCuu = MAPHG FROM PHONGBAN WHERE TENPHG = N'Nghiên cứu';

SELECT @LuongTBNghienCuu = AVG(LUONG) 
FROM NHANVIEN 
WHERE PHG = @MaPhongNghienCuu;

PRINT N'Lương trung bình phòng Nghiên cứu: ' + CAST(@LuongTBNghienCuu AS varchar(20));
PRINT N'Nhân viên có lương trên mức trung bình phòng Nghiên cứu:';

SELECT HONV + ' ' + ISNULL(TENLOT + ' ', '') + TENNV AS [Họ tên], LUONG
FROM NHANVIEN 
WHERE LUONG > @LuongTBNghienCuu;

DECLARE @MucLuongGioiHan float = 30000;

PRINT N'Phòng ban có lương trung bình trên ' + CAST(@MucLuongGioiHan AS varchar(20)) + ':';

SELECT p.TENPHG AS [Tên phòng ban], 
       COUNT(nv.MANV) AS [Số lượng nhân viên],
       AVG(nv.LUONG) AS [Lương trung bình]
FROM PHONGBAN p
INNER JOIN NHANVIEN nv ON p.MAPHG = nv.PHG
GROUP BY p.TENPHG, p.MAPHG
HAVING AVG(nv.LUONG) > @MucLuongGioiHan;

PRINT N'Thống kê số lượng đề án theo phòng ban:';

SELECT p.TENPHG AS [Tên phòng ban], 
       COUNT(da.MADA) AS [Số lượng đề án]
FROM PHONGBAN p
LEFT JOIN DEAN da ON p.MAPHG = da.PHONG
GROUP BY p.TENPHG, p.MAPHG
ORDER BY COUNT(da.MADA) DESC;



USE QLDA;
GO

DECLARE @ManvCanTim nvarchar(9) = '333445555';
DECLARE @TongThoiGian float;
DECLARE @TenNhanVien nvarchar(50);

SELECT @TongThoiGian = SUM(pc.THOIGIAN),
       @TenNhanVien = nv.HONV + ' ' + ISNULL(nv.TENLOT + ' ', '') + nv.TENNV
FROM PHANCONG pc
INNER JOIN NHANVIEN nv ON pc.MANV = nv.MANV
WHERE pc.MANV = @ManvCanTim
GROUP BY nv.HONV, nv.TENLOT, nv.TENNV;

PRINT N'Tổng thời gian làm việc của ' + @TenNhanVien + 
      N': ' + CAST(@TongThoiGian AS varchar(10)) + N' giờ';

DECLARE @SoThanNhan int;

SELECT @SoThanNhan = COUNT(*)
FROM THANNHAN tn
WHERE tn.MANV = @ManvCanTim;

PRINT N'Số thân nhân của ' + @TenNhanVien + N': ' + CAST(@SoThanNhan AS varchar(5));